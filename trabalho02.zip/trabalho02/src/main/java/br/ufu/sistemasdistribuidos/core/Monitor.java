/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufu.sistemasdistribuidos.core;

import java.math.BigInteger;
import java.net.InetAddress;
import java.util.ArrayList;

public class Monitor {

	private BigInteger chave;
	
	private ArrayList<String> comandos;
        
    

    public BigInteger getChave() {
		return chave;
	}
	public void setChave(BigInteger chave) {
		this.chave = chave;
	}

    public ArrayList<String> getComandos() {
        return comandos;
    }

    public void setComandos(ArrayList<String> comandos) {
        this.comandos = comandos;
    }

        
}
