
package org.jpdna.grpchello;

import br.ufu.sistemasdistribuidos.servidor.Cliente;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import java.util.Scanner;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A simple client that requests a greeting from the {@link HelloWorldServer}.
 */
public class HelloWorldClient {
  private static final Logger logger = Logger.getLogger(HelloWorldClient.class.getName());

  private final ManagedChannel channel;
  private final GreeterGrpc.GreeterBlockingStub blockingStub;

  /** Construct client connecting to HelloWorld server at {@code host:port}. */
  public HelloWorldClient(String host, int port) {
    channel = ManagedChannelBuilder.forAddress(host, port)
        .usePlaintext(true)
        .build();
    blockingStub = GreeterGrpc.newBlockingStub(channel);
  }

  public void shutdown() throws InterruptedException {
    channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
  }
  
  
  
  /** Say hello to server. */
  public void greet() throws InterruptedException {
    while(true){
        
        try {
          for(int i=0; i < Cliente.chavesMonitoradas.size(); i++){
              String chave = Cliente.chavesMonitoradas.get(i);
              boolean status = Cliente.chaveMonitoradasStatus.get(i);
              int cont = Cliente.chaveMonitoradasCont.get(i);
              String sendString = (status ? "ATT:"+chave+":"+cont : "CON:"+chave);
              HelloRequest request = HelloRequest.newBuilder().setName(sendString).build();
              
              HelloResponse response = blockingStub.sayHello(request);
              Cliente.readMonitorResponse(response.getMessage(), i);
          }
         
          //logger.info("Greeting: " + response.getMessage());
        } catch (RuntimeException e) {
          logger.log(Level.WARNING, "RPC failed", e);
          return;
        }

        Thread.sleep(100);
   }
     
  }

  /**
   * Greet server. If provided, the first element of {@code args} is the name to use in the
   * greeting.
   */
  public static void main(String[] args) throws Exception {
    HelloWorldClient client = new HelloWorldClient("localhost", 50051);
    try {
      /* Access a service running on the local machine on port 50051 */
    
      client.greet();
    } finally {
      client.shutdown();
    }
  }
}
