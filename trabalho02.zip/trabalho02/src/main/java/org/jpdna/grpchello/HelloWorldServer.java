

package org.jpdna.grpchello;

import br.edu.sistemasdistribuidos.cliente.Servidor;
import br.ufu.sistemasdistribuidos.core.Monitor;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import java.math.BigInteger;
import java.util.ArrayList;

import java.util.logging.Logger;

/**
 * Server that manages startup/shutdown of a {@code Greeter} server.
 */
public class HelloWorldServer {
  private static final Logger logger = Logger.getLogger(HelloWorldServer.class.getName());

  /* The port on which the server should run */
  private int port = 50051;
  private Server server;

  public void start() throws Exception {
    server = ServerBuilder.forPort(port)
        .addService(GreeterGrpc.bindService(new GreeterImpl()))
        .build()
        .start();
    logger.info("Server started, listening on " + port);
    Runtime.getRuntime().addShutdownHook(new Thread() {
      @Override
      public void run() {
        // Use stderr here since the logger may have been reset by its JVM shutdown hook.
        System.err.println("*** shutting down gRPC server since JVM is shutting down");
        HelloWorldServer.this.stop();
        System.err.println("*** server shut down");
      }
    });
  }

  private void stop() {
    if (server != null) {
      server.shutdown();
    }
  }

  /**
   * Await termination on the main thread since the grpc library uses daemon threads.
   */
  public void blockUntilShutdown() throws InterruptedException {
    if (server != null) {
      server.awaitTermination();
    }
  }

  /**
   * Main launches the server from the command line.
   */

  private class GreeterImpl implements GreeterGrpc.Greeter {

    @Override
    public void sayHello(HelloRequest req, StreamObserver<HelloResponse> responseObserver) {
        
        
      HelloResponse reply = HelloResponse.newBuilder().setMessage(readCommand(req.getName())).build();
      responseObserver.onNext(reply);
      responseObserver.onCompleted();
   
    }
  }
  
  public String readCommand(String c){
      
      String data[] = c.split(":");
      
      String r = "-1";
      if(data[0].equals("CON")){
        for(Monitor m: Servidor.monitores){
          if((""+m.getChave()).equals(data[1])){
              return m.getComandos().size()+"";
          }
        }
        Monitor m = new Monitor();
        m.setChave(new BigInteger(data[1]));
        m.setComandos(new ArrayList<String>());
        Servidor.monitores.add(m);
        r = "0";
      }else if(data[0].equals("ATT")){
        
        Monitor a = null;
        for(Monitor m: Servidor.monitores){
          
          if((""+m.getChave()).equals(data[1])){
              a = m;
              break;
          }
        }
        if(a == null){
            r = "-1";
        }else{
            System.out.println(data[2] + " " + a.getComandos().size());
            if(Integer.parseInt(data[2]) == a.getComandos().size()){
                r = "0";
            }else{
                r = a.getComandos().get(Integer.parseInt(data[2]));
            }
        }
      }

      return r;
  }
  
}
